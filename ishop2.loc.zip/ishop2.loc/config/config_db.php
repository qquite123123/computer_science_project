<?php

return [
    'dsn' => 'mysql:host=localhost;dbname=ishop2;charset=utf8',
    'user' => 'root',
    'pass' => '',
];